-- Scenario 1
CREATE OR REPLACE PROCEDURE SafeTransferFunds(senderid IN NUMBER, recieverid in NUMBER, amnt IN NUMBER)
IS
    bal NUMBER;
    BEGIN
        SELECT BALANCE INTO bal FROM ACCOUNTS WHERE ACCOUNTID = senderid;
        
        IF bal < amnt THEN
            RAISE_APPLICATION_ERROR(-20009, 'INSUFFICIENT BALANCE');
        END IF;

        UPDATE ACCOUNTS
            SET BALANCE = BALANCE - amnt WHERE ACCOUNTID = senderid;
        UPDATE ACCOUNTS
            SET BALANCE = BALANCE + amnt WHERE ACCOUNTID = recieverid;
    
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(SQLERRM);
            ROLLBACK;
    END;

SET SERVEROUTPUT ON;
BEGIN
    SafeTransferFunds(2,1,2300);
END;


-- Scenario 2
CREATE OR REPLACE PROCEDURE UpdateSalary(empid IN NUMBER, perc IN NUMBER)
IS
    BEGIN
        UPDATE EMPLOYEES
            SET SALARY = SALARY + SALARY * (perc/100) WHERE EMPLOYEEID = empid;

        IF SQL%ROWCOUNT = 0 THEN
            RAISE NO_DATA_FOUND;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Employee ID ' || empid || ' not exist');
    END;

SET SERVEROUTPUT ON;
BEGIN
    UpdateSalary(2, 1);
END;


-- Scenario 3
CREATE OR REPLACE PROCEDURE AddNewCustomer(id IN NUMBER, custname IN VARCHAR2, birthdate IN VARCHAR2, bal IN NUMBER)
IS
    birthd DATE;
    BEGIN
        birthd := TO_DATE(birthdate, 'DD-MM-YYYY');
        INSERT INTO CUSTOMERS(CUSTOMERID, NAME, DOB, BALANCE)
        VALUES(id, custname, birthd, bal);
    
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            DBMS_OUTPUT.PUT_LINE('Employee id already exist');
            ROLLBACK;
    END;

SET SERVEROUTPUT ON;
BEGIN
    AddNewCustomer(2,'Harry Potter', '30-04-2002', 2500);
END;

