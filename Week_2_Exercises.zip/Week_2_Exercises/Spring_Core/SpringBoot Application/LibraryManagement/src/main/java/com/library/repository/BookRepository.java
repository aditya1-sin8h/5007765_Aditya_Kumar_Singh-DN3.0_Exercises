package com.library.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.entity.Book;

//extending the class with JpaRepository to get all the CRUD methods and functions
public interface BookRepository extends JpaRepository<Book, Integer>{
	
}
